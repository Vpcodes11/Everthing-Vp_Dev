import { useEffect } from "react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function WelcomeSection() {
  useScrollAnimation();

  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-playfair font-bold text-navy mb-6 animate-on-scroll">
          Welcome to Tavta
        </h2>
        <p className="text-lg text-warm-gray max-w-3xl mx-auto leading-relaxed animate-on-scroll">
          Nestled between pristine beaches and lush tropical gardens, Tavta Clubs & Resorts offers
          an extraordinary escape where luxury meets tranquility. Our world-class amenities and
          personalized service create unforgettable experiences for the discerning traveler.
        </p>
        <div className="flex justify-center items-center mt-12 space-x-12">
          <div className="text-center animate-on-scroll-left hover-lift">
            <h3 className="text-3xl font-playfair font-bold text-gold mb-2 gradient-text">25+</h3>
            <p className="text-warm-gray">Years of Excellence</p>
          </div>
          <div className="text-center animate-on-scroll-scale hover-lift">
            <h3 className="text-3xl font-playfair font-bold text-gold mb-2 gradient-text">150</h3>
            <p className="text-warm-gray">Luxury Suites</p>
          </div>
          <div className="text-center animate-on-scroll-right hover-lift">
            <h3 className="text-3xl font-playfair font-bold text-gold mb-2 gradient-text">50+</h3>
            <p className="text-warm-gray">Premium Amenities</p>
          </div>
        </div>
      </div>
    </section>
  );
}
