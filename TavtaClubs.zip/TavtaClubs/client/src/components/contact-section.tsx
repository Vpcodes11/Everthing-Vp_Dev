import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Phone, Mail, MapPin, Send } from "lucide-react";
import { FaFacebookF, FaInstagram, FaTwitter, FaYoutube } from "react-icons/fa";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

interface InquiryData {
  firstName: string;
  lastName: string;
  email: string;
  checkInDate: string;
  checkOutDate: string;
  numberOfGuests: string;
  specialRequests: string;
}

export default function ContactSection() {
  useScrollAnimation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState<InquiryData>({
    firstName: "",
    lastName: "",
    email: "",
    checkInDate: "",
    checkOutDate: "",
    numberOfGuests: "",
    specialRequests: ""
  });

  const inquiryMutation = useMutation({
    mutationFn: async (data: InquiryData) => {
      const response = await apiRequest("POST", "/api/inquiries", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Inquiry Sent Successfully",
        description: "Thank you for your interest. We'll contact you within 24 hours.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        checkInDate: "",
        checkOutDate: "",
        numberOfGuests: "",
        specialRequests: ""
      });
      queryClient.invalidateQueries({ queryKey: ["/api/inquiries"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send inquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.firstName || !formData.lastName || !formData.email) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    inquiryMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof InquiryData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20 bg-navy text-white relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gold/20 rounded-full animate-parallax-float"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-white/10 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/3 w-20 h-20 bg-rose-gold/30 rounded-full animate-pulse-slow"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="animate-on-scroll-left">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-6 gradient-text">
              Plan Your Escape
            </h2>
            <p className="text-lg text-gray-300 mb-8 leading-relaxed animate-on-scroll">
              Ready to experience luxury redefined? Contact our reservation specialists or submit an
              inquiry to begin planning your perfect getaway.
            </p>

            <div className="space-y-6 mb-8">
              <div className="flex items-center animate-on-scroll hover-lift" style={{ animationDelay: '0.2s' }}>
                <div className="bg-gold rounded-full p-3 mr-4 animate-pulse-slow">
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">Reservations</h3>
                  <p className="text-gray-300">+1 (555) 123-4567</p>
                </div>
              </div>

              <div className="flex items-center animate-on-scroll hover-lift" style={{ animationDelay: '0.4s' }}>
                <div className="bg-gold rounded-full p-3 mr-4 animate-pulse-slow">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">Email</h3>
                  <p className="text-gray-300">reservations@tavta.com</p>
                </div>
              </div>

              <div className="flex items-center animate-on-scroll hover-lift" style={{ animationDelay: '0.6s' }}>
                <div className="bg-gold rounded-full p-3 mr-4 animate-pulse-slow">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">Location</h3>
                  <p className="text-gray-300">Paradise Bay, Tropical Islands</p>
                </div>
              </div>
            </div>

            <div className="flex space-x-4 animate-on-scroll" style={{ animationDelay: '0.8s' }}>
              <a href="#" className="text-gray-300 hover:text-gold transition-all duration-300 transform hover:scale-125 hover-glow">
                <FaFacebookF className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-gold transition-all duration-300 transform hover:scale-125 hover-glow">
                <FaInstagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-gold transition-all duration-300 transform hover:scale-125 hover-glow">
                <FaTwitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-gold transition-all duration-300 transform hover:scale-125 hover-glow">
                <FaYoutube className="h-6 w-6" />
              </a>
            </div>
          </div>

          <div className="glass-effect rounded-2xl p-8 animate-on-scroll-right hover-lift">
            <h3 className="text-2xl font-playfair font-semibold mb-6 gradient-text">Request Information</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  type="text"
                  placeholder="First Name *"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  className="bg-white/20 border-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-gold"
                  required
                />
                <Input
                  type="text"
                  placeholder="Last Name *"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  className="bg-white/20 border-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-gold"
                  required
                />
              </div>

              <Input
                type="email"
                placeholder="Email Address *"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-gold"
                required
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  type="date"
                  placeholder="Check-in Date"
                  value={formData.checkInDate}
                  onChange={(e) => handleInputChange("checkInDate", e.target.value)}
                  className="bg-white/20 border-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-gold"
                />
                <Input
                  type="date"
                  placeholder="Check-out Date"
                  value={formData.checkOutDate}
                  onChange={(e) => handleInputChange("checkOutDate", e.target.value)}
                  className="bg-white/20 border-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-gold"
                />
              </div>

              <Select value={formData.numberOfGuests} onValueChange={(value) => handleInputChange("numberOfGuests", value)}>
                <SelectTrigger className="bg-white/20 border-white/30 text-white focus:ring-2 focus:ring-gold">
                  <SelectValue placeholder="Number of Guests" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Guest</SelectItem>
                  <SelectItem value="2">2 Guests</SelectItem>
                  <SelectItem value="3">3 Guests</SelectItem>
                  <SelectItem value="4+">4+ Guests</SelectItem>
                </SelectContent>
              </Select>

              <Textarea
                placeholder="Special Requests or Comments"
                rows={4}
                value={formData.specialRequests}
                onChange={(e) => handleInputChange("specialRequests", e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-gold resize-none"
              />

              <Button
                type="submit"
                disabled={inquiryMutation.isPending}
                className="w-full bg-gold hover:bg-yellow-600 text-white py-4 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed hover-glow group"
              >
                <span className="flex items-center justify-center">
                  {inquiryMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Sending...
                    </>
                  ) : (
                    <>
                      Send Inquiry
                      <Send className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                    </>
                  )}
                </span>
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
