import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import WelcomeSection from "@/components/welcome-section";
import AmenitiesSection from "@/components/amenities-section";
import AccommodationSection from "@/components/accommodation-section";
import DiningSection from "@/components/dining-section";
import GallerySection from "@/components/gallery-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <>
      <Navigation />
      <HeroSection />
      <WelcomeSection />
      <AmenitiesSection />
      <AccommodationSection />
      <DiningSection />
      <GallerySection />
      <ContactSection />
      <Footer />
    </>
  );
}
