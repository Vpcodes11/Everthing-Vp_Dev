import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? "bg-white/95 backdrop-blur-md shadow-lg" : "bg-white/90 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-playfair font-bold text-navy">Tavta</h1>
            <p className="text-xs text-warm-gray -mt-1">CLUBS & RESORTS</p>
          </div>

          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button
                onClick={() => scrollToSection("home")}
                className="text-navy hover:text-gold transition-all duration-300 font-medium relative group"
              >
                Home
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button
                onClick={() => scrollToSection("amenities")}
                className="text-warm-gray hover:text-gold transition-all duration-300 font-medium relative group"
              >
                Amenities
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button
                onClick={() => scrollToSection("rooms")}
                className="text-warm-gray hover:text-gold transition-all duration-300 font-medium relative group"
              >
                Accommodation
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button
                onClick={() => scrollToSection("dining")}
                className="text-warm-gray hover:text-gold transition-all duration-300 font-medium relative group"
              >
                Dining
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-warm-gray hover:text-gold transition-all duration-300 font-medium relative group"
              >
                Contact
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
              </button>
            </div>
          </div>

          <div className="hidden md:block">
            <Button
              onClick={() => scrollToSection("contact")}
              className="bg-gold hover:bg-yellow-600 text-white px-6 py-2 rounded-full font-medium transition-all duration-200 transform hover:scale-105"
            >
              Book Now
            </Button>
          </div>

          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-navy hover:text-gold"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 bg-white shadow-lg">
            <button
              onClick={() => scrollToSection("home")}
              className="block w-full text-left px-3 py-2 text-navy hover:text-gold transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("amenities")}
              className="block w-full text-left px-3 py-2 text-warm-gray hover:text-gold transition-colors"
            >
              Amenities
            </button>
            <button
              onClick={() => scrollToSection("rooms")}
              className="block w-full text-left px-3 py-2 text-warm-gray hover:text-gold transition-colors"
            >
              Accommodation
            </button>
            <button
              onClick={() => scrollToSection("dining")}
              className="block w-full text-left px-3 py-2 text-warm-gray hover:text-gold transition-colors"
            >
              Dining
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="block w-full text-left px-3 py-2 text-warm-gray hover:text-gold transition-colors"
            >
              Contact
            </button>
            <Button
              onClick={() => scrollToSection("contact")}
              className="w-full mt-4 bg-gold hover:bg-yellow-600 text-white px-6 py-2 rounded-full font-medium"
            >
              Book Now
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}
