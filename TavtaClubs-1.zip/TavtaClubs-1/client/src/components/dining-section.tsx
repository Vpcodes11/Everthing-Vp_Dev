import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function DiningSection() {
  useScrollAnimation();
  const restaurants = [
    {
      name: "Oceana Restaurant",
      type: "Fine Dining",
      description: "Award-winning fine dining featuring fresh seafood and international cuisine with panoramic ocean views.",
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Sunset Grill",
      type: "Casual Dining",
      description: "Casual beachfront dining with grilled specialties, tropical cocktails, and stunning sunset views.",
      image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Sky Lounge",
      type: "Bar & Lounge",
      description: "Sophisticated rooftop bar offering craft cocktails, light bites, and 360-degree panoramic views.",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <section id="dining" className="py-20 bg-cream relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-20 w-40 h-40 bg-gold/10 rounded-full animate-parallax-float"></div>
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-navy/10 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-navy mb-6 animate-on-scroll gradient-text">
            Culinary Excellence
          </h2>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto animate-on-scroll">
            Savor world-class cuisine at our signature restaurants, each offering unique flavors and
            ambiance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {restaurants.map((restaurant, index) => (
            <Card 
              key={index} 
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover-lift hover-glow animate-on-scroll-scale group cursor-pointer"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={restaurant.image}
                  alt={restaurant.name}
                  className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <CardContent className="p-6 relative">
                <h3 className="text-2xl font-playfair font-semibold text-navy mb-3 group-hover:text-gold transition-colors duration-300">
                  {restaurant.name}
                </h3>
                <p className="text-warm-gray mb-4 group-hover:text-gray-700 transition-colors duration-300">
                  {restaurant.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-gold font-medium gradient-text">{restaurant.type}</span>
                  <button className="text-navy hover:text-gold transition-all duration-300 flex items-center group-hover:translate-x-1">
                    View Menu <ArrowRight className="ml-1 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </button>
                </div>
                {/* Animated border */}
                <div className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-gold to-rose-gold transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
