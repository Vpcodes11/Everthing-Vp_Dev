import { Card, CardContent } from "@/components/ui/card";
import { Waves, Sparkles, Dumbbell, Umbrella } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function AmenitiesSection() {
  useScrollAnimation();

  const amenities = [
    {
      icon: <Waves className="h-8 w-8 text-gold animate-float" />,
      title: "Infinity Pools",
      description: "Multiple stunning pools with breathtaking ocean views and swim-up bars",
      image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    },
    {
      icon: <Sparkles className="h-8 w-8 text-gold animate-pulse-slow" />,
      title: "World-Class Spa",
      description: "Rejuvenating treatments and wellness therapies in serene surroundings",
      image: "https://images.unsplash.com/photo-1600334129128-685c5582fd35?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    },
    {
      icon: <Dumbbell className="h-8 w-8 text-gold animate-float" />,
      title: "Fitness Center",
      description: "State-of-the-art equipment and personal training services available",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    },
    {
      icon: <Umbrella className="h-8 w-8 text-gold animate-float" />,
      title: "Beach Activities",
      description: "Water sports, beach volleyball, and exclusive beachfront access",
      image: "https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <section id="amenities" className="py-20 bg-cream relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gold opacity-10 rounded-full animate-parallax-float"></div>
        <div className="absolute bottom-20 right-10 w-24 h-24 bg-navy opacity-10 rounded-full animate-parallax-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-navy mb-6 animate-on-scroll gradient-text">
            Luxury Amenities
          </h2>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto animate-on-scroll">
            Indulge in our world-class facilities designed to rejuvenate your body, mind, and spirit
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {amenities.map((amenity, index) => (
            <Card
              key={index}
              className={`bg-white rounded-2xl shadow-lg overflow-hidden hover-lift hover-glow animate-on-scroll-scale group cursor-pointer`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={amenity.image}
                  alt={amenity.title}
                  className="w-full h-48 object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute top-4 right-4 bg-white/90 p-2 rounded-full transform scale-0 group-hover:scale-100 transition-transform duration-300">
                  {amenity.icon}
                </div>
              </div>
              <CardContent className="p-6 relative">
                <div className="mb-3 transform transition-transform duration-300 group-hover:scale-110">
                  {amenity.icon}
                </div>
                <h3 className="text-xl font-playfair font-semibold text-navy mb-2 group-hover:text-gold transition-colors duration-300">
                  {amenity.title}
                </h3>
                <p className="text-warm-gray text-sm group-hover:text-gray-700 transition-colors duration-300">
                  {amenity.description}
                </p>
                {/* Animated border */}
                <div className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-gold to-rose-gold transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
