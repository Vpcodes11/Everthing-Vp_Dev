import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import ThreeBackground from "./three-background";

export default function HeroSection() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: (e.clientY / window.innerHeight) * 2 - 1,
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section id="home" className="relative h-screen overflow-hidden">
      {/* Three.js Background */}
      <ThreeBackground />
      
      {/* Background Image with Parallax */}
      <div className="absolute inset-0 bg-black">
        <img
          src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"
          alt="Luxury resort exterior with ocean view"
          className="w-full h-full object-cover opacity-60 parallax"
          data-speed="0.5"
          style={{
            transform: `translate(${mousePosition.x * 10}px, ${mousePosition.y * 10}px)`,
            transition: 'transform 0.1s ease-out',
          }}
        />
      </div>

      {/* Enhanced Gradient Overlay */}
      <div className="hero-gradient absolute inset-0"></div>



      {/* Main Content */}
      <div className="relative z-10 h-full flex items-center justify-center text-center px-4">
        <div className="max-w-4xl mx-auto">

          
          <h1 className="text-5xl md:text-7xl font-playfair font-bold text-white mb-6 animate-fade-in-delay-1 gradient-text">
            Escape to Paradise
          </h1>
          <p className="text-xl md:text-2xl text-cream mb-8 font-light animate-fade-in-delay-2">
            Experience unparalleled luxury at Tavta Clubs & Resorts
          </p>
          
          {/* Enhanced Buttons */}
          <div className="space-x-4 animate-fade-in-delay-3">
            <Button
              onClick={() => scrollToSection("amenities")}
              className="bg-gold hover:bg-yellow-600 text-white px-8 py-4 rounded-full font-medium text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover-glow animate-shimmer"
            >
              Explore Our Resort
            </Button>
            <Button
              onClick={() => scrollToSection("gallery")}
              className="bg-gold hover:bg-yellow-600 text-white px-8 py-4 rounded-full font-medium text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover-glow animate-shimmer"
            >
              View Gallery
            </Button>
          </div>

          {/* Stats Counter */}
          <div className="flex justify-center items-center mt-12 space-x-8 animate-fade-in-delay-3">
            <div className="text-center glass-effect px-4 py-2 rounded-lg">
              <h3 className="text-2xl font-playfair font-bold text-gold mb-1">25+</h3>
              <p className="text-cream text-sm">Years</p>
            </div>
            <div className="text-center glass-effect px-4 py-2 rounded-lg">
              <h3 className="text-2xl font-playfair font-bold text-gold mb-1">150</h3>
              <p className="text-cream text-sm">Suites</p>
            </div>
            <div className="text-center glass-effect px-4 py-2 rounded-lg">
              <h3 className="text-2xl font-playfair font-bold text-gold mb-1">50+</h3>
              <p className="text-cream text-sm">Amenities</p>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white">
        <div className="animate-bounce">
          <ChevronDown className="h-8 w-8 animate-pulse" />
        </div>
        <div className="text-xs mt-2 opacity-80">Scroll to explore</div>
      </div>
    </section>
  );
}
