import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

export default function AccommodationSection() {
  useScrollAnimation();

  return (
    <section id="rooms" className="py-20 bg-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-40 right-10 w-48 h-48 bg-cream rounded-full opacity-50 animate-parallax-float"></div>
        <div className="absolute bottom-40 left-10 w-32 h-32 bg-gold/20 rounded-full animate-float" style={{ animationDelay: '3s' }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-navy mb-6 animate-on-scroll gradient-text">
            Luxury Accommodation
          </h2>
          <p className="text-lg text-warm-gray max-w-2xl mx-auto animate-on-scroll">
            Choose from our collection of elegantly appointed suites and villas, each offering
            unparalleled comfort and stunning views
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="order-2 lg:order-1 animate-on-scroll-left">
            <div className="relative group overflow-hidden rounded-2xl">
              <img
                src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
                alt="Luxury oceanview suite interior"
                className="w-full h-96 object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          </div>
          <div className="order-1 lg:order-2 animate-on-scroll-right">
            <h3 className="text-3xl font-playfair font-bold text-navy mb-4 gradient-text">Ocean View Suites</h3>
            <p className="text-warm-gray mb-6 leading-relaxed">
              Wake up to panoramic ocean views in our spacious suites featuring king-size beds,
              marble bathrooms, and private balconies. Each suite is meticulously designed with
              contemporary furnishings and luxury amenities.
            </p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-warm-gray animate-on-scroll hover-lift" style={{ animationDelay: '0.1s' }}>
                <Check className="h-5 w-5 text-gold mr-3 animate-float" />
                750 sq ft of elegantly appointed space
              </li>
              <li className="flex items-center text-warm-gray animate-on-scroll hover-lift" style={{ animationDelay: '0.2s' }}>
                <Check className="h-5 w-5 text-gold mr-3 animate-float" />
                Private balcony with ocean views
              </li>
              <li className="flex items-center text-warm-gray animate-on-scroll hover-lift" style={{ animationDelay: '0.3s' }}>
                <Check className="h-5 w-5 text-gold mr-3 animate-float" />
                Marble bathroom with soaking tub
              </li>
              <li className="flex items-center text-warm-gray animate-on-scroll hover-lift" style={{ animationDelay: '0.4s' }}>
                <Check className="h-5 w-5 text-gold mr-3 animate-float" />
                24/7 concierge service
              </li>
            </ul>
            <Button className="bg-gold hover:bg-yellow-600 text-white px-6 py-3 rounded-full font-medium transition-all duration-300 transform hover:scale-105 hover-glow animate-on-scroll">
              View Details
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-3xl font-playfair font-bold text-navy mb-4">Presidential Villas</h3>
            <p className="text-warm-gray mb-6 leading-relaxed">
              Experience the ultimate in luxury with our presidential villas featuring private pools,
              dedicated butler service, and expansive living spaces. Perfect for families or groups
              seeking exclusive privacy and personalized service.
            </p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-warm-gray">
                <Check className="h-5 w-5 text-gold mr-3" />
                2,500 sq ft of premium living space
              </li>
              <li className="flex items-center text-warm-gray">
                <Check className="h-5 w-5 text-gold mr-3" />
                Private infinity pool and garden
              </li>
              <li className="flex items-center text-warm-gray">
                <Check className="h-5 w-5 text-gold mr-3" />
                Dedicated butler and chef services
              </li>
              <li className="flex items-center text-warm-gray">
                <Check className="h-5 w-5 text-gold mr-3" />
                Multiple bedrooms and bathrooms
              </li>
            </ul>
            <Button className="bg-gold hover:bg-yellow-600 text-white px-6 py-3 rounded-full font-medium transition-all duration-200 transform hover:scale-105">
              View Details
            </Button>
          </div>
          <div>
            <img
              src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80"
              alt="Presidential villa with private pool"
              className="w-full h-96 object-cover rounded-2xl shadow-xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
