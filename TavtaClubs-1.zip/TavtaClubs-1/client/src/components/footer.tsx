import { FaFacebookF, FaInstagram, FaTwitter, FaYoutube } from "react-icons/fa";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-playfair font-bold mb-4">Tavta Clubs & Resorts</h3>
            <p className="text-gray-400 mb-4 leading-relaxed">
              Creating extraordinary experiences and lasting memories for discerning travelers
              seeking luxury, comfort, and unparalleled service in paradise.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-gold transition-colors duration-200">
                <FaFacebookF className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors duration-200">
                <FaInstagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors duration-200">
                <FaTwitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors duration-200">
                <FaYoutube className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <button
                  onClick={() => scrollToSection("amenities")}
                  className="hover:text-gold transition-colors duration-200"
                >
                  Amenities
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("rooms")}
                  className="hover:text-gold transition-colors duration-200"
                >
                  Accommodation
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("dining")}
                  className="hover:text-gold transition-colors duration-200"
                >
                  Dining
                </button>
              </li>
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Activities
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Spa & Wellness
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Guest Services</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Reservations
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Concierge
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Transportation
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Event Planning
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-gold transition-colors duration-200">
                  Special Offers
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Tavta Clubs & Resorts. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  );
}
