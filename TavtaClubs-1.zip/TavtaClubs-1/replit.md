# Tavta Clubs & Resorts - Luxury Resort Website

## Overview

This is a modern full-stack web application for Tavta Clubs & Resorts, a luxury resort website featuring elegant design, advanced animations with Three.js, scroll-based interactions, inquiry management, and comprehensive resort information. The application is built using a modern tech stack with React frontend, Express backend, and PostgreSQL database integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui components
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Design**: RESTful endpoints with JSON responses
- **Middleware**: Custom logging and error handling

### Design System & Animation Framework
- **Typography**: Playfair Display for headings, Inter for body text
- **Color Scheme**: Navy, gold, cream, and warm gray palette with gradient effects
- **Components**: Custom luxury-themed components with consistent styling and advanced animations
- **Responsive**: Mobile-first responsive design approach
- **Animations**: 
  - Three.js 3D backgrounds with floating particles and wave effects
  - Scroll-triggered animations using Intersection Observer
  - Advanced CSS keyframe animations (fade, slide, scale, float, shimmer, parallax)
  - Hover effects with transforms, shadows, and glow effects
  - Mouse parallax for enhanced interactivity
  - Smooth transitions with cubic-bezier easing

## Key Components

### Database Schema
- **Users Table**: Authentication system foundation (id, username, password)
- **Inquiries Table**: Customer inquiry management (contact info, stay details, special requests)
- **Schema Validation**: Zod schemas for type-safe data validation

### API Endpoints
- `POST /api/inquiries` - Create new customer inquiry
- `GET /api/inquiries` - Retrieve all inquiries (admin functionality)

### Frontend Pages & Sections
- **Hero Section**: Full-screen banner with Three.js particle background, mouse parallax, floating elements, and call-to-action buttons
- **Welcome Section**: Resort introduction with key statistics and scroll animations
- **Amenities Section**: Showcase of resort facilities with hover effects, image scaling, and staggered animations
- **Accommodation Section**: Luxury suite details with parallax backgrounds and interactive hover states
- **Dining Section**: Restaurant showcase with advanced card animations and gradient overlays
- **Gallery Section**: Interactive visual showcase with modal lightbox and shimmer effects
- **Contact Section**: Animated inquiry form with glass morphism effects and enhanced validation feedback
- **Navigation**: Fixed header with animated underlines, backdrop blur, and smooth scrolling navigation

### Animation System
- **Three.js Background**: Particle system with floating gold/white/blue particles, animated wave geometry with shader materials
- **Scroll Animations**: Intersection Observer-based animations with fade, slide, and scale effects
- **CSS Animation Library**: 15+ keyframe animations including float, shimmer, parallax-float, and custom easing
- **Hover Effects**: Lift animations, glow effects, image scaling, and gradient overlays
- **Interactive Elements**: Mouse-following parallax, animated form states, and real-time visual feedback
- **Performance Optimized**: GPU-accelerated transforms, efficient intersection observers, and cleanup on component unmount

### Storage Layer
- **Production**: PostgreSQL with Drizzle ORM and Neon Database
- **Database Integration**: DatabaseStorage class implementing IStorage interface
- **Schema Management**: Drizzle ORM with automatic UUID generation and timestamp tracking
- **Interface**: IStorage abstraction for consistent data operations

## Data Flow

1. **Client Interaction**: User interacts with React components
2. **Form Submission**: Contact form data validated with Zod schemas
3. **API Request**: TanStack Query manages HTTP requests to Express backend
4. **Server Processing**: Express routes handle business logic and validation
5. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
6. **Response Handling**: Success/error states managed by React Query and toast notifications

## External Dependencies

### UI & Styling
- **Radix UI**: Accessible UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework
- **React Icons**: Icon library for social media and UI icons
- **Lucide React**: Modern icon library for interface elements

### Data & State Management
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Zod**: Runtime type validation and schema definition

### Development Tools
- **Vite**: Build tool with HMR and optimized production builds
- **TypeScript**: Static type checking across full stack
- **ESLint/Prettier**: Code quality and formatting (implied by structure)

### Database & Backend
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle Kit**: Database migration and schema management
- **Express**: Web application framework

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle Kit manages schema migrations

### Environment Configuration
- **Development**: Local development with hot reloading via Vite
- **Production**: Compiled server serves static frontend assets
- **Database**: PostgreSQL connection via DATABASE_URL environment variable

### Scripts
- `npm run dev` - Development server with hot reloading
- `npm run build` - Production build for both frontend and backend
- `npm run start` - Production server startup
- `npm run db:push` - Database schema deployment

### Hosting Considerations
- **Frontend**: Static assets can be served by Express or CDN
- **Backend**: Node.js server deployment (Replit, Vercel, Railway, etc.)
- **Database**: Neon Database provides serverless PostgreSQL
- **Environment Variables**: DATABASE_URL required for production deployment

The application is designed for easy deployment on platforms like Replit, with a single server handling both API requests and static file serving in production.