# Tatva Luxury Resort Website

## Overview

This is a full-stack luxury resort website for "Tatva Clubs & Resorts" built with React, TypeScript, Express.js, and designed with a premium aesthetic featuring modern animations and responsive design. The application showcases various resort amenities, accommodations, dining options, and wellness services through an elegant, immersive user experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client-side and server-side code:

- **Frontend**: React with TypeScript running on Vite
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but using in-memory storage currently)
- **Styling**: Tailwind CSS with shadcn/ui components
- **Build System**: Vite for frontend, esbuild for backend production builds

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: wouter for client-side routing
- **State Management**: TanStack Query for server state, React hooks for local state
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom luxury theme colors
- **Animations**: Framer Motion for smooth animations and transitions
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database Layer**: Drizzle ORM configured for PostgreSQL
- **Session Management**: connect-pg-simple for PostgreSQL sessions
- **Development**: tsx for TypeScript execution in development

### UI Design System
- **Component Library**: shadcn/ui components with consistent theming
- **Design Tokens**: CSS custom properties for colors, spacing, and typography
- **Typography**: Playfair Display for headings, system fonts for body text
- **Color Scheme**: Luxury gold (#D4AF37) with midnight navy (#1E293B) and warm neutrals
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints

## Data Flow

### Current Implementation
- **Storage**: PostgreSQL database with Drizzle ORM for full data persistence
- **API Structure**: RESTful endpoints under `/api` prefix with full CRUD operations
- **Client-Server Communication**: React Query for state management with optimistic updates
- **Error Handling**: Centralized error handling with toast notifications and proper validation

### Database Schema
The application uses PostgreSQL with the following tables:

#### Users Table
- `id`: UUID primary key with auto-generation
- `username`: Unique text field
- `password`: Text field for authentication

#### Contact Inquiries Table
- `id`: UUID primary key with auto-generation
- `name`: Guest name (required)
- `email`: Contact email (required)
- `interest`: Area of interest (required)
- `message`: Inquiry message (required)
- `createdAt`: Timestamp of inquiry submission

#### Bookings Table
- `id`: UUID primary key with auto-generation
- `guestName`: Guest name (required)
- `email`: Contact email (required)
- `phone`: Contact phone number (required)
- `checkIn`: Check-in date (required)
- `checkOut`: Check-out date (required)
- `roomType`: Type of accommodation (required)
- `guests`: Number of guests (required)
- `specialRequests`: Additional requests (optional)
- `totalAmount`: Total booking amount in cents (required)
- `status`: Booking status (pending/confirmed/cancelled)
- `createdAt`: Timestamp of booking creation

All tables use Zod schemas for validation and type safety

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database driver for serverless environments
- **drizzle-orm & drizzle-kit**: Type-safe ORM and migration tools
- **@tanstack/react-query**: Server state management and caching
- **framer-motion**: Animation library for smooth UI transitions
- **wouter**: Lightweight client-side routing

### UI Dependencies
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant creation for components
- **cmdk**: Command palette component

### Development Tools
- **vite**: Fast build tool with HMR
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Development Environment
- **Frontend**: Vite dev server with HMR on client directory
- **Backend**: tsx execution with file watching for auto-restart
- **Database**: Configured for local PostgreSQL with environment variables
- **Asset Handling**: Vite handles static assets and bundling

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Database**: Drizzle migrations handle schema updates
- **Environment**: Production-ready with proper error handling and logging

### Key Features
- **Luxury Branding**: Premium visual design with gold accents and elegant typography
- **Spectacular Glow Effects**: Advanced CSS animations with cinematic hover transformations
- **Complete Database System**: Full PostgreSQL integration with contact inquiries and booking management
- **Booking System**: Interactive room selection with real-time pricing and reservation functionality
- **Admin Dashboard**: Complete database management interface at `/admin` route
- **Smooth Animations**: Framer Motion provides polished interactions and page transitions
- **Responsive Design**: Mobile-first approach ensuring great experience across devices
- **Accessibility**: Radix UI components provide WCAG-compliant accessibility
- **Performance**: Optimized builds with code splitting and asset optimization
- **Type Safety**: Full TypeScript coverage from database to UI components

### Database Status: FULLY OPERATIONAL
- **Contact Inquiries**: Successfully storing and retrieving guest inquiries
- **Booking Management**: Complete reservation system with room pricing and status tracking
- **API Endpoints**: All CRUD operations working with proper error handling
- **Admin Interface**: Full database viewing capabilities with real-time data
- **Data Validation**: Zod schemas ensuring data integrity throughout the system

The application is production-ready with a complete luxury resort experience featuring spectacular visual effects and robust database functionality.