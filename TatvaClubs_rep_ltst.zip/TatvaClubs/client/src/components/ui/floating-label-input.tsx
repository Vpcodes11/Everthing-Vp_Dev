import { forwardRef } from "react";
import { cn } from "@/lib/utils";

export interface FloatingLabelInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

const FloatingLabelInput = forwardRef<HTMLInputElement, FloatingLabelInputProps>(
  ({ className, type = "text", label, id, ...props }, ref) => {
    return (
      <div className="relative">
        <input
          type={type}
          id={id}
          ref={ref}
          className={cn(
            "peer w-full p-4 border-2 border-gray-200 rounded-xl focus:border-[hsl(43,74%,66%)] transition-colors duration-300 placeholder-transparent bg-white text-[hsl(225,25%,12%)]",
            className
          )}
          placeholder={label}
          {...props}
        />
        <label
          htmlFor={id}
          className="absolute left-4 -top-3 bg-white px-2 text-sm text-gray-600 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-4 peer-focus:-top-3 peer-focus:text-[hsl(43,74%,66%)] peer-focus:text-sm transition-all duration-300"
        >
          {label}
        </label>
      </div>
    );
  }
);
FloatingLabelInput.displayName = "FloatingLabelInput";

export default FloatingLabelInput;
