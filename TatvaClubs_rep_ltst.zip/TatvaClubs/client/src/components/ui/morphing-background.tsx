import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function MorphingBackground() {
  const [shapes, setShapes] = useState<Array<{ id: number; x: number; y: number; size: number; delay: number }>>([]);

  useEffect(() => {
    const newShapes = [];
    for (let i = 0; i < 8; i++) {
      newShapes.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: 20 + Math.random() * 40,
        delay: Math.random() * 5,
      });
    }
    setShapes(newShapes);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden opacity-20">
      {shapes.map((shape) => (
        <motion.div
          key={shape.id}
          className="absolute rounded-full"
          style={{
            left: `${shape.x}%`,
            top: `${shape.y}%`,
            width: `${shape.size}px`,
            height: `${shape.size}px`,
            background: `radial-gradient(circle, rgba(212, 175, 55, 0.4) 0%, rgba(212, 175, 55, 0.1) 50%, transparent 100%)`,
            filter: `blur(${shape.size / 8}px)`,
          }}
          animate={{
            scale: [1, 1.5, 0.8, 1.2, 1],
            rotate: [0, 180, 360],
            x: [0, 50, -30, 20, 0],
            y: [0, -40, 30, -20, 0],
            opacity: [0.3, 0.8, 0.2, 0.6, 0.3],
          }}
          transition={{
            duration: 15 + Math.random() * 10,
            delay: shape.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
      
      {/* Additional gradient overlays */}
      <motion.div
        className="absolute inset-0"
        style={{
          background: `conic-gradient(from 0deg, 
            transparent 0deg, 
            rgba(212, 175, 55, 0.1) 90deg, 
            transparent 180deg, 
            rgba(212, 175, 55, 0.1) 270deg, 
            transparent 360deg
          )`,
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      />
      
      <motion.div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(ellipse 80% 50% at 50% 50%, 
            rgba(212, 175, 55, 0.1) 0%, 
            transparent 50%
          )`,
        }}
        animate={{
          scale: [1, 1.2, 0.8, 1],
          opacity: [0.3, 0.1, 0.5, 0.3],
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}