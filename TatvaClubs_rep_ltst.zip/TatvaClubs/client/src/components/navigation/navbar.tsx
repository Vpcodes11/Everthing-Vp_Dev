import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 w-full z-40 transition-all duration-300 ${
        isScrolled
          ? "bg-[hsl(225,25%,12%)]/95 backdrop-blur-md"
          : "glass-morphism"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="font-playfair text-2xl font-bold text-gradient cursor-pointer"
            onClick={() => scrollToSection("home")}
          >
            Tatva
          </motion.div>
          
          <div className="hidden md:flex space-x-8">
            {[
              { name: "Home", id: "home" },
              { name: "Experiences", id: "experiences" },
              { name: "Accommodations", id: "accommodations" },
              { name: "Dining", id: "dining" },
              { name: "Contact", id: "contact" },
            ].map((item) => (
              <motion.button
                key={item.name}
                whileHover={{ scale: 1.05 }}
                onClick={() => scrollToSection(item.id)}
                className="hover:text-[hsl(43,74%,66%)] transition-colors duration-300"
              >
                {item.name}
              </motion.button>
            ))}
          </div>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="glow-button bg-[hsl(43,74%,66%)] text-[hsl(225,25%,12%)] px-6 py-2 rounded-full font-medium relative overflow-hidden"
          >
            Book Now
          </motion.button>
        </div>
      </div>
    </motion.nav>
  );
}
