import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Leaf, Waves, Dumbbell, Heart } from "lucide-react";

const services = [
  {
    icon: Leaf,
    title: "Holistic Treatments",
    description: "Traditional therapies combined with modern techniques",
  },
  {
    icon: Waves,
    title: "Hydrotherapy",
    description: "Rejuvenating water-based wellness experiences",
  },
  {
    icon: Dumbbell,
    title: "Fitness Center",
    description: "State-of-the-art equipment with personal trainers",
  },
  {
    icon: Heart,
    title: "Meditation",
    description: "Guided sessions in peaceful, natural settings",
  },
];

export default function Wellness() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      className="py-20 bg-gradient-to-br from-[hsl(45,87%,94%)] to-[hsl(210,20%,98%)] text-[hsl(225,25%,12%)]"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <motion.img
              whileHover={{ scale: 1.05 }}
              src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Luxury spa treatment room with natural elements"
              className="rounded-2xl shadow-2xl transition-all duration-500"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h2 className="font-playfair text-5xl font-bold mb-6">
              Wellness <span className="text-gradient">Sanctuary</span>
            </h2>
            <p className="text-xl mb-8 opacity-80">
              Discover tranquility in our award-winning spa, where ancient
              healing traditions meet modern luxury in a serene environment
              designed for complete rejuvenation.
            </p>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <motion.div
                    key={service.title}
                    initial={{ opacity: 0, y: 30 }}
                    animate={
                      isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }
                    }
                    transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
                    className="bg-white bg-opacity-60 p-6 rounded-xl hover:bg-opacity-80 transition-all duration-300 cursor-pointer group"
                  >
                    <Icon className="text-[hsl(43,74%,66%)] w-8 h-8 mb-4 group-hover:scale-110 transition-transform duration-300" />
                    <h4 className="font-semibold text-lg mb-2">
                      {service.title}
                    </h4>
                    <p className="opacity-70">{service.description}</p>
                  </motion.div>
                );
              })}
            </div>

            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: "0 0 30px rgba(212, 175, 55, 0.6), 0 0 50px rgba(212, 175, 55, 0.4)"
              }}
              whileTap={{ scale: 0.95 }}
              className="glow-button luxury-gradient text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 relative overflow-hidden"
            >
              Book Spa Treatment
            </motion.button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
