import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Check } from "lucide-react";

const features = [
  {
    title: "Presidential Suites",
    description: "Ultra-luxury accommodations with panoramic views",
  },
  {
    title: "Private Villas",
    description: "Exclusive retreats with personal butler service",
  },
  {
    title: "Ocean View Suites",
    description: "Wake up to stunning ocean vistas every morning",
  },
];

export default function Accommodations() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      id="accommodations"
      className="py-20 bg-[hsl(45,87%,94%)] text-[hsl(225,25%,12%)]"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-playfair text-5xl font-bold mb-6">
              Extraordinary <span className="text-gradient">Accommodations</span>
            </h2>
            <p className="text-xl mb-8 opacity-80">
              Each suite is a masterpiece of design and comfort, offering
              unparalleled luxury with breathtaking views and personalized
              service that exceeds every expectation.
            </p>

            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -30 }}
                  animate={
                    isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }
                  }
                  transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                  className="flex items-center space-x-4"
                >
                  <div className="w-12 h-12 bg-[hsl(43,74%,66%)] rounded-full flex items-center justify-center flex-shrink-0">
                    <Check className="text-[hsl(225,25%,12%)] w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">{feature.title}</h4>
                    <p className="opacity-70">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: "0 0 30px rgba(212, 175, 55, 0.6), 0 0 50px rgba(212, 175, 55, 0.4)"
              }}
              whileTap={{ scale: 0.95 }}
              className="glow-button mt-8 luxury-gradient text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 relative overflow-hidden"
            >
              View All Accommodations
            </motion.button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <motion.img
              whileHover={{ scale: 1.05 }}
              src="https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Luxury hotel suite with elegant furnishings"
              className="rounded-2xl shadow-2xl transition-all duration-500"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
