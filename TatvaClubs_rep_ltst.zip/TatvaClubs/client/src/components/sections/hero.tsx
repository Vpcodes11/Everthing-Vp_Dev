import { motion } from "framer-motion";
import { Gem, Star } from "lucide-react";
import FloatingParticles from "@/components/ui/floating-particles";
import MorphingBackground from "@/components/ui/morphing-background";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="home"
      className="relative h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image with Parallax */}
      <motion.div
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 10 }}
        className="absolute inset-0 bg-cover bg-center bg-fixed"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
        }}
      />
      <div className="absolute inset-0 bg-black bg-opacity-40" />
      
      {/* Morphing Background */}
      <MorphingBackground />
      
      {/* Floating Particles */}
      <FloatingParticles count={20} />

      {/* Hero Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-6">
        <motion.h1
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="font-playfair text-6xl md:text-8xl font-bold mb-6"
        >
          <motion.span 
            className="text-gradient neon-glow"
            animate={{ 
              textShadow: [
                "0 0 5px rgba(212, 175, 55, 0.8), 0 0 10px rgba(212, 175, 55, 0.6)",
                "0 0 20px rgba(212, 175, 55, 1), 0 0 30px rgba(212, 175, 55, 0.8), 0 0 40px rgba(212, 175, 55, 0.6)",
                "0 0 5px rgba(212, 175, 55, 0.8), 0 0 10px rgba(212, 175, 55, 0.6)"
              ]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            Luxury
          </motion.span>
          <br />
          <span className="text-white">Redefined</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="text-xl md:text-2xl text-[hsl(210,20%,98%)] mb-8 opacity-90"
        >
          Experience unparalleled elegance at Tatva Clubs & Resorts, where every
          moment becomes a treasured memory
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => scrollToSection("experiences")}
            className="glow-button bg-[hsl(43,74%,66%)] text-[hsl(225,25%,12%)] px-8 py-4 rounded-full font-semibold transition-all duration-300 shadow-lg"
          >
            Explore Our Resorts
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="glow-button glass-morphism px-8 py-4 rounded-full font-semibold transition-all duration-300"
          >
            Watch Our Story
          </motion.button>
        </motion.div>
      </div>

      {/* Floating Elements */}
      <motion.div
        animate={{ 
          y: [0, -20, 0],
          rotate: [0, 360]
        }}
        transition={{ 
          y: { duration: 6, repeat: Infinity },
          rotate: { duration: 12, repeat: Infinity, ease: "linear" }
        }}
        className="absolute bottom-10 left-10 z-20"
      >
        <div className="glow-effect glass-morphism p-4 rounded-lg pulse-glow">
          <Star className="text-[hsl(43,74%,66%)] w-8 h-8" />
        </div>
      </motion.div>

      <motion.div
        animate={{ 
          y: [0, -20, 0],
          rotate: [360, 0],
          scale: [1, 1.1, 1]
        }}
        transition={{ 
          y: { duration: 6, repeat: Infinity, delay: -2 },
          rotate: { duration: 8, repeat: Infinity, ease: "linear" },
          scale: { duration: 4, repeat: Infinity }
        }}
        className="absolute top-1/4 right-10 z-20"
      >
        <div className="glow-effect glass-morphism p-4 rounded-lg pulse-glow">
          <Gem className="text-[hsl(43,74%,66%)] w-8 h-8" />
        </div>
      </motion.div>

      {/* Additional floating elements */}
      <motion.div
        animate={{ 
          x: [0, 50, 0],
          y: [0, -30, 0],
          rotate: [0, 180, 360]
        }}
        transition={{ 
          duration: 10, 
          repeat: Infinity,
          delay: 1
        }}
        className="absolute top-1/3 left-1/4 z-20"
      >
        <div className="w-3 h-3 bg-[hsl(43,74%,66%)] rounded-full opacity-80 glow-effect"
          style={{
            boxShadow: "0 0 20px rgba(212, 175, 55, 0.8)"
          }}
        />
      </motion.div>

      <motion.div
        animate={{ 
          x: [0, -40, 0],
          y: [0, 25, 0],
          scale: [0.8, 1.2, 0.8]
        }}
        transition={{ 
          duration: 8, 
          repeat: Infinity,
          delay: 3
        }}
        className="absolute bottom-1/3 right-1/4 z-20"
      >
        <div className="w-2 h-2 bg-[hsl(43,74%,66%)] rounded-full opacity-60"
          style={{
            boxShadow: "0 0 15px rgba(212, 175, 55, 0.6)"
          }}
        />
      </motion.div>
    </section>
  );
}
