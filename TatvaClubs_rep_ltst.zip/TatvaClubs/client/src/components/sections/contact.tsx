import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Phone, Mail, MapPin } from "lucide-react";
import FloatingLabelInput from "@/components/ui/floating-label-input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const contactInfo = [
  {
    icon: Phone,
    title: "Reservations",
    detail: "+1 (555) 123-LUXURY",
  },
  {
    icon: Mail,
    title: "Email",
    detail: "reservations@tatvaresorts.com",
  },
  {
    icon: MapPin,
    title: "Location",
    detail: "Multiple Exclusive Destinations",
  },
];

export default function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    interest: "",
    message: "",
  });

  const queryClient = useQueryClient();
  
  const contactMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("/api/contact", "POST", data),
    onSuccess: () => {
      toast({
        title: "Thank you for your inquiry!",
        description: "Our luxury travel specialists will contact you shortly.",
      });
      setFormData({ name: "", email: "", interest: "", message: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/contact"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send your inquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.interest || !formData.message) {
      toast({
        title: "Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section
      id="contact"
      className="py-20 bg-[hsl(45,87%,94%)] text-[hsl(225,25%,12%)]"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-playfair text-5xl font-bold mb-6">
              Begin Your <span className="text-gradient">Journey</span>
            </h2>
            <p className="text-xl mb-8 opacity-80">
              Contact our luxury travel specialists to craft your perfect
              escape. Every detail will be tailored to create an unforgettable
              experience.
            </p>

            <div className="space-y-6 mb-8">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                return (
                  <motion.div
                    key={info.title}
                    initial={{ opacity: 0, x: -30 }}
                    animate={
                      isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }
                    }
                    transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                    className="flex items-center space-x-4"
                  >
                    <div className="w-12 h-12 luxury-gradient rounded-full flex items-center justify-center">
                      <Icon className="text-white w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{info.title}</h4>
                      <p className="opacity-70">{info.detail}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            whileHover={{ 
              rotateY: 2,
              rotateX: 2,
              scale: 1.02
            }}
            className="perspective-1000"
          >
            <form
              onSubmit={handleSubmit}
              className="glow-effect bg-white rounded-2xl p-8 shadow-2xl transform-gpu"
            >
              <h3 className="font-playfair text-2xl font-bold mb-6">
                Request Information
              </h3>

              <div className="space-y-6">
                <FloatingLabelInput
                  id="name"
                  name="name"
                  type="text"
                  label="Full Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />

                <FloatingLabelInput
                  id="email"
                  name="email"
                  type="email"
                  label="Email Address"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />

                <div className="relative">
                  <select
                    id="interest"
                    name="interest"
                    value={formData.interest}
                    onChange={handleChange}
                    className="w-full p-4 border-2 border-gray-200 rounded-xl focus:border-[hsl(43,74%,66%)] transition-colors duration-300 bg-white"
                    required
                  >
                    <option value="">Select Interest</option>
                    <option value="accommodation">Luxury Accommodations</option>
                    <option value="wedding">Wedding & Events</option>
                    <option value="corporate">Corporate Retreats</option>
                    <option value="spa">Spa & Wellness</option>
                  </select>
                </div>

                <div className="relative">
                  <textarea
                    id="message"
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    className="peer w-full p-4 border-2 border-gray-200 rounded-xl focus:border-[hsl(43,74%,66%)] transition-colors duration-300 placeholder-transparent resize-none"
                    placeholder="Tell us about your perfect getaway"
                    required
                  />
                  <label
                    htmlFor="message"
                    className="absolute left-4 -top-3 bg-white px-2 text-sm text-gray-600 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-4 peer-focus:-top-3 peer-focus:text-[hsl(43,74%,66%)] peer-focus:text-sm transition-all duration-300"
                  >
                    Tell us about your perfect getaway
                  </label>
                </div>

                <motion.button
                  type="submit"
                  disabled={contactMutation.isPending}
                  whileHover={{ 
                    scale: contactMutation.isPending ? 1 : 1.05,
                    boxShadow: contactMutation.isPending ? undefined : "0 0 30px rgba(212, 175, 55, 0.8), 0 0 50px rgba(212, 175, 55, 0.4)"
                  }}
                  whileTap={{ scale: contactMutation.isPending ? 1 : 0.98 }}
                  className={`glow-button w-full luxury-gradient text-white py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg border-none relative overflow-hidden ${
                    contactMutation.isPending ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                >
                  {contactMutation.isPending ? "Sending..." : "Send Inquiry"}
                </motion.button>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
