import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Bed, Utensils, Waves } from "lucide-react";

const experiences = [
  {
    icon: Bed,
    title: "Luxury Suites",
    description:
      "Spacious suites designed with meticulous attention to detail, featuring panoramic views and premium amenities",
    link: "Explore Suites →",
  },
  {
    icon: Utensils,
    title: "Culinary Excellence",
    description:
      "Award-winning restaurants featuring world-class chefs creating extraordinary culinary journeys",
    link: "Discover Dining →",
  },
  {
    icon: Waves,
    title: "Wellness Sanctuary",
    description:
      "Rejuvenate your mind, body, and soul with our comprehensive wellness and spa experiences",
    link: "Wellness Journey →",
  },
];

export default function ExperienceOverview() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      id="experiences"
      className="py-20 bg-gradient-to-b from-[hsl(225,25%,12%)] to-gray-900"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-playfair text-5xl font-bold mb-6">
            The <span className="text-gradient">Tatva</span> Experience
          </h2>
          <p className="text-xl text-[hsl(210,20%,98%)] max-w-3xl mx-auto">
            Immerse yourself in a world where luxury meets authenticity, where
            every detail is crafted to perfection
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {experiences.map((experience, index) => {
            const Icon = experience.icon;
            return (
              <motion.div
                key={experience.title}
                initial={{ opacity: 0, y: 50 }}
                animate={
                  isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }
                }
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ 
                  scale: 1.05,
                  rotateY: 5,
                  rotateX: 5,
                }}
                className="hover-lift glow-effect glass-morphism rounded-2xl p-8 text-center group cursor-pointer relative overflow-hidden"
              >
                <motion.div 
                  className="w-20 h-20 bg-[hsl(43,74%,66%)] rounded-full flex items-center justify-center mx-auto mb-6 relative"
                  whileHover={{ 
                    scale: 1.2,
                    rotate: 360,
                    boxShadow: "0 0 30px rgba(212, 175, 55, 0.8), 0 0 60px rgba(212, 175, 55, 0.4)"
                  }}
                  transition={{ 
                    scale: { duration: 0.3 },
                    rotate: { duration: 0.8 },
                    boxShadow: { duration: 0.3 }
                  }}
                >
                  <Icon className="text-[hsl(225,25%,12%)] w-8 h-8" />
                  <motion.div
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: "conic-gradient(transparent, rgba(212, 175, 55, 0.3), transparent)"
                    }}
                    animate={{ rotate: 360 }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  />
                </motion.div>
                <h3 className="font-playfair text-2xl font-bold mb-4">
                  {experience.title}
                </h3>
                <p className="text-[hsl(210,20%,98%)] opacity-90 mb-6">
                  {experience.description}
                </p>
                <button className="text-[hsl(43,74%,66%)] hover:underline font-medium group-hover:text-white transition-colors duration-300">
                  {experience.link}
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
