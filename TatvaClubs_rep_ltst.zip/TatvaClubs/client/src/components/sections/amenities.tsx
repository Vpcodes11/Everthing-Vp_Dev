import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const amenities = [
  {
    image:
      "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    title: "Infinity Pool",
    description: "Breathtaking ocean views",
  },
  {
    image:
      "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    title: "Championship Golf",
    description: "18-hole professional course",
  },
  {
    image:
      "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    title: "Private Marina",
    description: "Exclusive yacht experiences",
  },
];

export default function Amenities() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section className="py-20 bg-[hsl(225,25%,12%)]" ref={ref}>
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-playfair text-5xl font-bold mb-6">
            Premium <span className="text-gradient">Amenities</span>
          </h2>
          <p className="text-xl text-[hsl(210,20%,98%)] max-w-3xl mx-auto">
            Every detail has been carefully considered to ensure your stay
            exceeds all expectations
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {amenities.map((amenity, index) => (
            <motion.div
              key={amenity.title}
              initial={{ opacity: 0, y: 50 }}
              animate={
                isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }
              }
              transition={{ duration: 0.8, delay: index * 0.2 }}
              whileHover={{ 
                scale: 1.03,
                rotateY: 3,
                boxShadow: "0 0 50px rgba(212, 175, 55, 0.5), 0 0 100px rgba(212, 175, 55, 0.2)"
              }}
              className="hover-lift glow-effect group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl">
                <motion.img
                  whileHover={{ scale: 1.1 }}
                  src={amenity.image}
                  alt={amenity.title}
                  className="w-full h-64 object-cover transition-all duration-500"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-6 glass-morphism">
                  <h3 className="font-playfair text-xl font-bold text-white mb-2">
                    {amenity.title}
                  </h3>
                  <p className="text-white opacity-90 text-sm">
                    {amenity.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
