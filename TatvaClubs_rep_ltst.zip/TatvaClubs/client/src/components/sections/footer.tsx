import { motion } from "framer-motion";
import { Facebook, Instagram, Twitter } from "lucide-react";

const destinations = [
  "Maldives Resort",
  "Swiss Alps Retreat", 
  "Bali Sanctuary",
  "Tuscany Villa"
];

const services = [
  "Luxury Accommodations",
  "Fine Dining",
  "Spa & Wellness", 
  "Private Events"
];

const contactDetails = [
  "Reservations: +1 (555) 123-LUXURY",
  "Email: info@tatvaresorts.com",
  "Concierge: Available 24/7"
];

export default function Footer() {
  return (
    <footer className="bg-[hsl(225,25%,12%)] py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-playfair text-2xl font-bold text-gradient mb-4">
              Tatva
            </h3>
            <p className="text-[hsl(210,20%,98%)] opacity-80 mb-6">
              Where luxury meets authenticity, creating unforgettable
              experiences for discerning travelers.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Instagram, Twitter].map((Icon, index) => (
                <motion.a
                  key={index}
                  href="#"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 luxury-gradient rounded-full flex items-center justify-center transition-all duration-300"
                >
                  <Icon className="text-white w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-lg mb-4 text-[hsl(43,74%,66%)]">
              Destinations
            </h4>
            <ul className="space-y-2 text-[hsl(210,20%,98%)] opacity-80">
              {destinations.map((destination) => (
                <li key={destination}>
                  <a
                    href="#"
                    className="hover:text-[hsl(43,74%,66%)] transition-colors duration-300"
                  >
                    {destination}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-lg mb-4 text-[hsl(43,74%,66%)]">
              Services
            </h4>
            <ul className="space-y-2 text-[hsl(210,20%,98%)] opacity-80">
              {services.map((service) => (
                <li key={service}>
                  <a
                    href="#"
                    className="hover:text-[hsl(43,74%,66%)] transition-colors duration-300"
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-lg mb-4 text-[hsl(43,74%,66%)]">
              Contact
            </h4>
            <ul className="space-y-2 text-[hsl(210,20%,98%)] opacity-80">
              {contactDetails.map((detail) => (
                <li key={detail}>{detail}</li>
              ))}
            </ul>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="border-t border-gray-700 mt-12 pt-8 text-center text-[hsl(210,20%,98%)] opacity-60"
        >
          <p>
            &copy; 2024 Tatva Clubs & Resorts. All rights reserved. Luxury
            redefined.
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
