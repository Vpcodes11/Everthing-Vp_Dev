import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const restaurants = [
  {
    image:
      "https://images.unsplash.com/photo-1559329007-40df8a9345d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    title: "Signature Restaurant",
    description:
      "Michelin-starred dining experience featuring contemporary cuisine with local influences",
  },
  {
    image:
      "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    title: "Sky Lounge",
    description:
      "Sophisticated cocktails and panoramic city views in an elegant rooftop setting",
  },
  {
    image:
      "https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    title: "Private Dining",
    description:
      "Intimate dining experiences tailored to your preferences with personal chef service",
  },
];

export default function Dining() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      id="dining"
      className="py-20 bg-[hsl(225,25%,12%)] relative overflow-hidden"
      ref={ref}
    >
      {/* Background overlay */}
      <div
        className="absolute inset-0 opacity-20 bg-cover bg-center bg-fixed"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
        }}
      />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-playfair text-5xl font-bold mb-6">
            Culinary <span className="text-gradient">Artistry</span>
          </h2>
          <p className="text-xl text-[hsl(210,20%,98%)] max-w-3xl mx-auto">
            Embark on a gastronomic journey where world-renowned chefs create
            extraordinary flavors using the finest ingredients
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {restaurants.map((restaurant, index) => (
            <motion.div
              key={restaurant.title}
              initial={{ opacity: 0, y: 50 }}
              animate={
                isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }
              }
              transition={{ duration: 0.8, delay: index * 0.2 }}
              whileHover={{ 
                scale: 1.05,
                rotateY: 5,
                boxShadow: "0 0 40px rgba(212, 175, 55, 0.4), 0 0 80px rgba(212, 175, 55, 0.2)"
              }}
              className="hover-lift glow-effect group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl mb-6">
                <motion.img
                  whileHover={{ scale: 1.1 }}
                  src={restaurant.image}
                  alt={restaurant.title}
                  className="w-full h-64 object-cover transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <h3 className="font-playfair text-2xl font-bold text-white">
                    {restaurant.title}
                  </h3>
                </div>
              </div>
              <p className="text-[hsl(210,20%,98%)] opacity-90 group-hover:opacity-100 transition-opacity duration-300">
                {restaurant.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
