import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef, useState } from "react";
import { Calendar, Users, Phone, Mail, User } from "lucide-react";
import FloatingLabelInput from "@/components/ui/floating-label-input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function BookingSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    guestName: "",
    email: "",
    phone: "",
    checkIn: "",
    checkOut: "",
    roomType: "",
    guests: 1,
    specialRequests: "",
  });

  const queryClient = useQueryClient();
  
  const bookingMutation = useMutation({
    mutationFn: (data: typeof formData) => {
      // Calculate total amount based on room type (in cents)
      const roomPrices = {
        "Presidential Suite": 150000, // $1500
        "Ocean Villa": 120000, // $1200
        "Garden Suite": 80000, // $800
        "Standard Room": 50000, // $500
      };
      const totalAmount = roomPrices[data.roomType as keyof typeof roomPrices] || 50000;
      
      return apiRequest("/api/bookings", "POST", {
        ...data,
        totalAmount,
        status: "pending"
      });
    },
    onSuccess: () => {
      toast({
        title: "Booking Request Submitted!",
        description: "We'll confirm your luxury reservation shortly.",
      });
      setFormData({
        guestName: "",
        email: "",
        phone: "",
        checkIn: "",
        checkOut: "",
        roomType: "",
        guests: 1,
        specialRequests: "",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.guestName || !formData.email || !formData.phone || !formData.checkIn || !formData.checkOut || !formData.roomType) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    bookingMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section ref={ref} className="py-32 px-4 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-r from-amber-400/10 to-yellow-600/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-r from-amber-500/10 to-orange-600/10 rounded-full blur-3xl animate-float-delayed"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent mb-6">
            Reserve Your
            <br />
            <span className="italic">Luxury Escape</span>
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Book your extraordinary stay at Tatva Clubs & Resorts where every moment becomes a cherished memory
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Room Types */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <h3 className="text-3xl font-bold text-amber-400 mb-8">Choose Your Accommodation</h3>
            
            <div className="space-y-6">
              {[
                { name: "Presidential Suite", price: "$1,500", features: ["Ocean View", "Private Butler", "Jacuzzi"] },
                { name: "Ocean Villa", price: "$1,200", features: ["Beach Access", "Private Pool", "Garden"] },
                { name: "Garden Suite", price: "$800", features: ["Garden View", "Terrace", "Luxury Amenities"] },
                { name: "Standard Room", price: "$500", features: ["Comfort", "Modern Design", "Quality Service"] }
              ].map((room, index) => (
                <motion.div
                  key={room.name}
                  whileHover={{ 
                    scale: 1.02,
                    boxShadow: "0 0 30px rgba(212, 175, 55, 0.3)"
                  }}
                  className={`glass-card p-6 rounded-2xl cursor-pointer transition-all duration-300 border-2 ${
                    formData.roomType === room.name 
                      ? "border-amber-400 glow-border" 
                      : "border-white/10 hover:border-amber-400/50"
                  }`}
                  onClick={() => handleInputChange("roomType", room.name)}
                >
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="text-xl font-semibold text-white">{room.name}</h4>
                    <span className="text-2xl font-bold text-amber-400">{room.price}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {room.features.map((feature, idx) => (
                      <span key={idx} className="px-3 py-1 bg-amber-400/20 text-amber-300 rounded-full text-sm">
                        {feature}
                      </span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Booking Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="glass-card p-8 rounded-3xl"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-400 z-10" size={20} />
                  <input
                    type="text"
                    value={formData.guestName}
                    onChange={(e) => handleInputChange("guestName", e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300"
                    placeholder="Full Name"
                    required
                  />
                </div>

                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-400 z-10" size={20} />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300"
                    placeholder="Email Address"
                    required
                  />
                </div>
              </div>

              <div className="relative group">
                <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-400 z-10" size={20} />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300"
                  placeholder="Phone Number"
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="relative group">
                  <Calendar className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-400 z-10" size={20} />
                  <input
                    type="date"
                    value={formData.checkIn}
                    onChange={(e) => handleInputChange("checkIn", e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300"
                    required
                  />
                </div>

                <div className="relative group">
                  <Calendar className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-400 z-10" size={20} />
                  <input
                    type="date"
                    value={formData.checkOut}
                    onChange={(e) => handleInputChange("checkOut", e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300"
                    required
                  />
                </div>
              </div>

              <div className="relative group">
                <Users className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-400 z-10" size={20} />
                <select
                  value={formData.guests}
                  onChange={(e) => handleInputChange("guests", parseInt(e.target.value))}
                  className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/20 rounded-xl text-white focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300"
                >
                  {[1, 2, 3, 4, 5, 6].map(num => (
                    <option key={num} value={num} className="bg-slate-800">
                      {num} Guest{num > 1 ? 's' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative group">
                <textarea
                  value={formData.specialRequests}
                  onChange={(e) => handleInputChange("specialRequests", e.target.value)}
                  rows={4}
                  className="w-full p-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all duration-300 resize-none"
                  placeholder="Special requests or preferences..."
                />
              </div>

              <motion.button
                type="submit"
                disabled={bookingMutation.isPending}
                whileHover={{ 
                  scale: bookingMutation.isPending ? 1 : 1.05,
                  boxShadow: bookingMutation.isPending ? undefined : "0 0 30px rgba(212, 175, 55, 0.8), 0 0 50px rgba(212, 175, 55, 0.4)"
                }}
                whileTap={{ scale: bookingMutation.isPending ? 1 : 0.98 }}
                className={`glow-button w-full luxury-gradient text-white py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg border-none relative overflow-hidden ${
                  bookingMutation.isPending ? "opacity-70 cursor-not-allowed" : ""
                }`}
              >
                {bookingMutation.isPending ? "Processing..." : "Reserve Now"}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}