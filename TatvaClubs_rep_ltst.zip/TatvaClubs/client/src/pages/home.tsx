import { useEffect, useState } from "react";
import LoadingScreen from "@/components/ui/loading-screen";
import Navbar from "@/components/navigation/navbar";
import Hero from "@/components/sections/hero";
import ExperienceOverview from "@/components/sections/experience-overview";
import Accommodations from "@/components/sections/accommodations";
import Dining from "@/components/sections/dining";
import Wellness from "@/components/sections/wellness";
import Amenities from "@/components/sections/amenities";
import BookingSection from "@/components/sections/booking";
import Contact from "@/components/sections/contact";
import Footer from "@/components/sections/footer";

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-[hsl(225,25%,12%)] text-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <ExperienceOverview />
      <Accommodations />
      <Dining />
      <Wellness />
      <Amenities />
      <BookingSection />
      <Contact />
      <Footer />
    </div>
  );
}
