import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Calendar, Users, Mail, Phone, MapPin, Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";

export default function Admin() {
  const [activeTab, setActiveTab] = useState<"contact" | "bookings">("contact");

  const { data: contactData, isLoading: contactLoading } = useQuery({
    queryKey: ["/api/contact"],
    queryFn: () => fetch("/api/contact").then(res => res.json()),
  });

  const { data: bookingsData, isLoading: bookingsLoading } = useQuery({
    queryKey: ["/api/bookings"],
    queryFn: () => fetch("/api/bookings").then(res => res.json()),
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="text-green-400" size={20} />;
      case "cancelled":
        return <XCircle className="text-red-400" size={20} />;
      default:
        return <AlertCircle className="text-yellow-400" size={20} />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatAmount = (cents: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(cents / 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 text-white p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-5xl font-bold bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent mb-4">
            Tatva Resort Admin
          </h1>
          <p className="text-xl text-slate-300">
            Database Management & Guest Information
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex mb-8 glass-card rounded-2xl p-2 w-fit">
          <button
            onClick={() => setActiveTab("contact")}
            className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
              activeTab === "contact"
                ? "bg-amber-400 text-slate-900"
                : "text-amber-400 hover:bg-amber-400/10"
            }`}
          >
            Contact Inquiries ({contactData?.inquiries?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab("bookings")}
            className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
              activeTab === "bookings"
                ? "bg-amber-400 text-slate-900"
                : "text-amber-400 hover:bg-amber-400/10"
            }`}
          >
            Bookings ({bookingsData?.bookings?.length || 0})
          </button>
        </div>

        {/* Contact Inquiries Tab */}
        {activeTab === "contact" && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold text-amber-400 mb-8 flex items-center gap-3">
              <Mail />
              Contact Inquiries
            </h2>
            
            {contactLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin w-12 h-12 border-4 border-amber-400 border-t-transparent rounded-full mx-auto"></div>
                <p className="mt-4 text-slate-300">Loading inquiries...</p>
              </div>
            ) : (
              <div className="grid gap-6">
                {contactData?.inquiries?.length > 0 ? (
                  contactData.inquiries.map((inquiry: any, index: number) => (
                    <motion.div
                      key={inquiry.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="glass-card p-6 rounded-2xl border border-amber-400/20"
                    >
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <h3 className="text-xl font-semibold text-white mb-2">{inquiry.name}</h3>
                          <div className="flex items-center gap-2 text-slate-300 mb-2">
                            <Mail size={16} />
                            <span>{inquiry.email}</span>
                          </div>
                          <div className="flex items-center gap-2 text-slate-300 mb-4">
                            <MapPin size={16} />
                            <span className="px-3 py-1 bg-amber-400/20 text-amber-300 rounded-full text-sm">
                              {inquiry.interest}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-slate-400 text-sm">
                            <Clock size={16} />
                            <span>{formatDate(inquiry.createdAt)}</span>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 p-4 bg-white/5 rounded-xl">
                        <p className="text-slate-300 leading-relaxed">{inquiry.message}</p>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-12 glass-card rounded-2xl">
                    <Mail className="mx-auto mb-4 text-slate-400" size={48} />
                    <p className="text-slate-400">No contact inquiries yet</p>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}

        {/* Bookings Tab */}
        {activeTab === "bookings" && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold text-amber-400 mb-8 flex items-center gap-3">
              <Calendar />
              Reservations
            </h2>
            
            {bookingsLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin w-12 h-12 border-4 border-amber-400 border-t-transparent rounded-full mx-auto"></div>
                <p className="mt-4 text-slate-300">Loading bookings...</p>
              </div>
            ) : (
              <div className="grid gap-6">
                {bookingsData?.bookings?.length > 0 ? (
                  bookingsData.bookings.map((booking: any, index: number) => (
                    <motion.div
                      key={booking.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="glass-card p-6 rounded-2xl border border-amber-400/20"
                    >
                      <div className="grid lg:grid-cols-3 gap-6">
                        <div>
                          <h3 className="text-xl font-semibold text-white mb-2">{booking.guestName}</h3>
                          <div className="flex items-center gap-2 text-slate-300 mb-2">
                            <Mail size={16} />
                            <span>{booking.email}</span>
                          </div>
                          <div className="flex items-center gap-2 text-slate-300 mb-2">
                            <Phone size={16} />
                            <span>{booking.phone}</span>
                          </div>
                          <div className="flex items-center gap-2 text-slate-300">
                            <Users size={16} />
                            <span>{booking.guests} Guest{booking.guests > 1 ? 's' : ''}</span>
                          </div>
                        </div>
                        
                        <div>
                          <div className="mb-4">
                            <h4 className="text-amber-400 font-semibold mb-2">Accommodation</h4>
                            <p className="text-white">{booking.roomType}</p>
                          </div>
                          <div className="mb-4">
                            <h4 className="text-amber-400 font-semibold mb-2">Stay Duration</h4>
                            <p className="text-slate-300">
                              {new Date(booking.checkIn).toLocaleDateString()} - {new Date(booking.checkOut).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          <div className="mb-4">
                            <h4 className="text-amber-400 font-semibold mb-2">Total Amount</h4>
                            <p className="text-2xl font-bold text-white">{formatAmount(booking.totalAmount)}</p>
                          </div>
                          <div className="mb-4">
                            <h4 className="text-amber-400 font-semibold mb-2">Status</h4>
                            <div className="flex items-center gap-2">
                              {getStatusIcon(booking.status)}
                              <span className="capitalize text-white">{booking.status}</span>
                            </div>
                          </div>
                          <div className="text-sm text-slate-400">
                            <Clock size={16} className="inline mr-2" />
                            {formatDate(booking.createdAt)}
                          </div>
                        </div>
                      </div>
                      
                      {booking.specialRequests && (
                        <div className="mt-4 p-4 bg-white/5 rounded-xl">
                          <h4 className="text-amber-400 font-semibold mb-2">Special Requests</h4>
                          <p className="text-slate-300">{booking.specialRequests}</p>
                        </div>
                      )}
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-12 glass-card rounded-2xl">
                    <Calendar className="mx-auto mb-4 text-slate-400" size={48} />
                    <p className="text-slate-400">No bookings yet</p>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}